<?php
/**
 * Noppa Theme Theme functions and definitions
 */

// Laad de stylesheet van het hoofdthema in
add_action( 'wp_enqueue_scripts', 'noppa_enqueue_styles' );
function noppa_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}

// Voeg het Noppa Kleurenpalet toe aan de Gutenberg Editor
add_action( 'after_setup_theme', 'noppa_custom_colors' );
function noppa_custom_colors() {
    add_theme_support( 'editor-color-palette', array(
        array(
            'name'  => __( 'Noppa Cyan', 'noppa' ),
            'slug'  => 'noppa-cyan',
            'color' => '#00D0F0',
        ),
        array(
            'name'  => __( 'Noppa Sky', 'noppa' ),
            'slug'  => 'noppa-sky',
            'color' => '#20B0F0',
        ),
        array(
            'name'  => __( 'Noppa Royal', 'noppa' ),
            'slug'  => 'noppa-royal',
            'color' => '#2060E0',
        ),
        array(
            'name'  => __( 'Noppa Indigo', 'noppa' ),
            'slug'  => 'noppa-indigo',
            'color' => '#3A4FD0',
        ),
        array(
            'name'  => __( 'Noppa Navy', 'noppa' ),
            'slug'  => 'noppa-navy',
            'color' => '#0F2A66',
        ),
        array(
            'name'  => __( 'Ink (Tekst)', 'noppa' ),
            'slug'  => 'noppa-ink',
            'color' => '#1A2440',
        ),
        array(
            'name'  => __( 'Mist (Lichtgrijs)', 'noppa' ),
            'slug'  => 'noppa-mist',
            'color' => '#E4E9F2',
        ),
        array(
            'name'  => __( 'Light (Achtergrond)', 'noppa' ),
            'slug'  => 'noppa-light',
            'color' => '#F1F5FB',
        )
    ) );
}
